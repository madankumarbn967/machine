export const PORT = 3000
export const mongoDBURL = 'mongodb+srv://manu:test123@cluster0.ecc1a.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0'



